﻿using FurnitureStore.Models.Utils;
using NHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FurnitureStore.Models
{
    public class CartRepository : ICartRepository
    {
        private static NLog.Logger logger = NLog.LogManager.GetCurrentClassLogger();

        public List<Cart> GetAllCarts()
        {
            throw new NotImplementedException();
        }

        public void Save(Cart Cart)
        {
            try
            {
                using (ISession session = NHibernateHelper.OpenSession())
                {
                    using (ITransaction transaction = session.BeginTransaction())
                    {
                        session.Save(Cart);
                        transaction.Commit();
                    }
                    Console.WriteLine("DB save was successfull!");
                }
            }
            catch (Exception e)
            {
                logger.Error(e);
                Console.WriteLine(e);
                throw e;
            }
        }

        public Cart GetCartById()
        {
            throw new NotImplementedException();
        }

        public void RemoveCartById()
        {
            throw new NotImplementedException();
        }

        public void UpdateCartById()
        {
            throw new NotImplementedException();
        }
    }
}