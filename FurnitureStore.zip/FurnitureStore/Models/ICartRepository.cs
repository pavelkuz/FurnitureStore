﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FurnitureStore.Models
{
    interface ICartRepository
    {
        List<Cart> GetAllCarts();

        void Save(Cart Cart);

        Cart GetCartById();

        void RemoveCartById();

        void UpdateCartById();
    }
}
